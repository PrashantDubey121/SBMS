package com.example.employee_bonus.employee_bonus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeBonusApplicationTests {

	@Test
	void contextLoads() {
	}

}
